﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRunAdvancedAnalysis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdRun = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.TabBarriers = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkTotalPathDownHab = New System.Windows.Forms.CheckBox()
        Me.chkTotalDownHab = New System.Windows.Forms.CheckBox()
        Me.chkTotalUpHab = New System.Windows.Forms.CheckBox()
        Me.chkPathDownHab = New System.Windows.Forms.CheckBox()
        Me.chkDownHab = New System.Windows.Forms.CheckBox()
        Me.chkUpHab = New System.Windows.Forms.CheckBox()
        Me.frmLayersInclude = New System.Windows.Forms.GroupBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.lstLineLayers = New System.Windows.Forms.CheckedListBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstLineHabCls = New System.Windows.Forms.ListBox()
        Me.lstLineUnit = New System.Windows.Forms.ListBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lstLineHabQuan = New System.Windows.Forms.ListBox()
        Me.cmdChngLineCls = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lstPolyLayers = New System.Windows.Forms.CheckedListBox()
        Me.lstPolyUnit = New System.Windows.Forms.ListBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.cmdChngPolyCls = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstPolyHabCls = New System.Windows.Forms.ListBox()
        Me.lstPolyHabQuan = New System.Windows.Forms.ListBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cmdRemove2 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lstVlsExcld = New System.Windows.Forms.ListBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lstFtrsExcld = New System.Windows.Forms.ListBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lstLyrsExcld = New System.Windows.Forms.ListBox()
        Me.Farme3 = New System.Windows.Forms.GroupBox()
        Me.cmdAddExcld = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lstFields = New System.Windows.Forms.ListBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lstValues = New System.Windows.Forms.ListBox()
        Me.lstLayers = New System.Windows.Forms.ListBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.lstBarrierField = New System.Windows.Forms.ListBox()
        Me.lstNaturalTFField = New System.Windows.Forms.ListBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmdSelectNaturalTF = New System.Windows.Forms.Button()
        Me.lstPermField = New System.Windows.Forms.ListBox()
        Me.cmdBarrierID = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmdSelectBarrierPerm = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.chkLstBarriersLayers = New System.Windows.Forms.CheckedListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.frmDirection = New System.Windows.Forms.GroupBox()
        Me.OptDown = New System.Windows.Forms.RadioButton()
        Me.OptUp = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.chkDCISectional = New System.Windows.Forms.CheckBox()
        Me.cmdDCIModelDir = New System.Windows.Forms.Button()
        Me.txtDCIModelDir = New System.Windows.Forms.TextBox()
        Me.txtRInstallDir = New System.Windows.Forms.TextBox()
        Me.cmdRInstallDir = New System.Windows.Forms.Button()
        Me.chkDCI = New System.Windows.Forms.CheckBox()
        Me.chkNaturalTF = New System.Windows.Forms.CheckBox()
        Me.chkBarrierPerm = New System.Windows.Forms.CheckBox()
        Me.chkConnect = New System.Windows.Forms.CheckBox()
        Me.cmdAddGDB = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ChkDBFOutput = New System.Windows.Forms.CheckBox()
        Me.txtTablesPrefix = New System.Windows.Forms.TextBox()
        Me.txtGDB = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtOrder = New System.Windows.Forms.TextBox()
        Me.ChkMaxOrd = New System.Windows.Forms.CheckBox()
        Me.TabBarriers.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.frmLayersInclude.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.Farme3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.frmDirection.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdRun
        '
        Me.cmdRun.Location = New System.Drawing.Point(63, 541)
        Me.cmdRun.Name = "cmdRun"
        Me.cmdRun.Size = New System.Drawing.Size(75, 23)
        Me.cmdRun.TabIndex = 9
        Me.cmdRun.Text = "Run"
        Me.cmdRun.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(515, 541)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(75, 23)
        Me.cmdCancel.TabIndex = 10
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(277, 541)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(75, 23)
        Me.cmdSave.TabIndex = 11
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'TabBarriers
        '
        Me.TabBarriers.AllowDrop = True
        Me.TabBarriers.Controls.Add(Me.TabPage1)
        Me.TabBarriers.Controls.Add(Me.TabPage2)
        Me.TabBarriers.Controls.Add(Me.TabPage3)
        Me.TabBarriers.Controls.Add(Me.TabPage4)
        Me.TabBarriers.Location = New System.Drawing.Point(23, 23)
        Me.TabBarriers.Name = "TabBarriers"
        Me.TabBarriers.SelectedIndex = 0
        Me.TabBarriers.Size = New System.Drawing.Size(628, 497)
        Me.TabBarriers.TabIndex = 12
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.PictureBox4)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.frmLayersInclude)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(620, 471)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "General"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(139, 23)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(202, 20)
        Me.Label23.TabIndex = 13
        Me.Label23.Text = "FiPEx - General Options"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.FiPEX_AddIn_dotNet35_2.My.Resources.Resources.FiPEx_LOGOv3b_90x90
        Me.PictureBox4.Location = New System.Drawing.Point(22, 23)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(90, 90)
        Me.PictureBox4.TabIndex = 11
        Me.PictureBox4.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkTotalPathDownHab)
        Me.GroupBox3.Controls.Add(Me.chkTotalDownHab)
        Me.GroupBox3.Controls.Add(Me.chkTotalUpHab)
        Me.GroupBox3.Controls.Add(Me.chkPathDownHab)
        Me.GroupBox3.Controls.Add(Me.chkDownHab)
        Me.GroupBox3.Controls.Add(Me.chkUpHab)
        Me.GroupBox3.Location = New System.Drawing.Point(157, 53)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(406, 77)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Habitat Output"
        '
        'chkTotalPathDownHab
        '
        Me.chkTotalPathDownHab.AutoSize = True
        Me.chkTotalPathDownHab.Location = New System.Drawing.Point(255, 43)
        Me.chkTotalPathDownHab.Name = "chkTotalPathDownHab"
        Me.chkTotalPathDownHab.Size = New System.Drawing.Size(137, 17)
        Me.chkTotalPathDownHab.TabIndex = 5
        Me.chkTotalPathDownHab.Text = "Downstream Path Total"
        Me.chkTotalPathDownHab.UseVisualStyleBackColor = True
        '
        'chkTotalDownHab
        '
        Me.chkTotalDownHab.AutoSize = True
        Me.chkTotalDownHab.Location = New System.Drawing.Point(127, 43)
        Me.chkTotalDownHab.Name = "chkTotalDownHab"
        Me.chkTotalDownHab.Size = New System.Drawing.Size(112, 17)
        Me.chkTotalDownHab.TabIndex = 4
        Me.chkTotalDownHab.Text = "Downstream Total"
        Me.chkTotalDownHab.UseVisualStyleBackColor = True
        '
        'chkTotalUpHab
        '
        Me.chkTotalUpHab.AutoSize = True
        Me.chkTotalUpHab.Location = New System.Drawing.Point(15, 42)
        Me.chkTotalUpHab.Name = "chkTotalUpHab"
        Me.chkTotalUpHab.Size = New System.Drawing.Size(98, 17)
        Me.chkTotalUpHab.TabIndex = 3
        Me.chkTotalUpHab.Text = "Upstream Total"
        Me.chkTotalUpHab.UseVisualStyleBackColor = True
        '
        'chkPathDownHab
        '
        Me.chkPathDownHab.AutoSize = True
        Me.chkPathDownHab.Location = New System.Drawing.Point(255, 21)
        Me.chkPathDownHab.Name = "chkPathDownHab"
        Me.chkPathDownHab.Size = New System.Drawing.Size(110, 17)
        Me.chkPathDownHab.TabIndex = 2
        Me.chkPathDownHab.Text = "Downstream Path"
        Me.chkPathDownHab.UseVisualStyleBackColor = True
        '
        'chkDownHab
        '
        Me.chkDownHab.AutoSize = True
        Me.chkDownHab.Location = New System.Drawing.Point(127, 19)
        Me.chkDownHab.Name = "chkDownHab"
        Me.chkDownHab.Size = New System.Drawing.Size(85, 17)
        Me.chkDownHab.TabIndex = 1
        Me.chkDownHab.Text = "Downstream"
        Me.chkDownHab.UseVisualStyleBackColor = True
        '
        'chkUpHab
        '
        Me.chkUpHab.AutoSize = True
        Me.chkUpHab.Location = New System.Drawing.Point(15, 19)
        Me.chkUpHab.Name = "chkUpHab"
        Me.chkUpHab.Size = New System.Drawing.Size(71, 17)
        Me.chkUpHab.TabIndex = 0
        Me.chkUpHab.Text = "Upstream"
        Me.chkUpHab.UseVisualStyleBackColor = True
        '
        'frmLayersInclude
        '
        Me.frmLayersInclude.Controls.Add(Me.GroupBox8)
        Me.frmLayersInclude.Controls.Add(Me.GroupBox2)
        Me.frmLayersInclude.Controls.Add(Me.Label3)
        Me.frmLayersInclude.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmLayersInclude.Location = New System.Drawing.Point(16, 147)
        Me.frmLayersInclude.Name = "frmLayersInclude"
        Me.frmLayersInclude.Size = New System.Drawing.Size(598, 302)
        Me.frmLayersInclude.TabIndex = 1
        Me.frmLayersInclude.TabStop = False
        Me.frmLayersInclude.Text = "Network and Habitat Layers to Include in Analysis"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.lstLineLayers)
        Me.GroupBox8.Controls.Add(Me.Label18)
        Me.GroupBox8.Controls.Add(Me.Label1)
        Me.GroupBox8.Controls.Add(Me.lstLineHabCls)
        Me.GroupBox8.Controls.Add(Me.lstLineUnit)
        Me.GroupBox8.Controls.Add(Me.Label19)
        Me.GroupBox8.Controls.Add(Me.lstLineHabQuan)
        Me.GroupBox8.Controls.Add(Me.cmdChngLineCls)
        Me.GroupBox8.Location = New System.Drawing.Point(20, 19)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(563, 118)
        Me.GroupBox8.TabIndex = 26
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Line Layers"
        '
        'lstLineLayers
        '
        Me.lstLineLayers.FormattingEnabled = True
        Me.lstLineLayers.Location = New System.Drawing.Point(10, 22)
        Me.lstLineLayers.Name = "lstLineLayers"
        Me.lstLineLayers.Size = New System.Drawing.Size(306, 79)
        Me.lstLineLayers.TabIndex = 17
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label18.Location = New System.Drawing.Point(332, 22)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(78, 13)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = "Quantity Field*:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label1.Location = New System.Drawing.Point(372, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Units*:"
        '
        'lstLineHabCls
        '
        Me.lstLineHabCls.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lstLineHabCls.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstLineHabCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLineHabCls.ForeColor = System.Drawing.Color.Black
        Me.lstLineHabCls.FormattingEnabled = True
        Me.lstLineHabCls.Location = New System.Drawing.Point(426, 60)
        Me.lstLineHabCls.Name = "lstLineHabCls"
        Me.lstLineHabCls.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstLineHabCls.Size = New System.Drawing.Size(113, 13)
        Me.lstLineHabCls.TabIndex = 11
        '
        'lstLineUnit
        '
        Me.lstLineUnit.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lstLineUnit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstLineUnit.ForeColor = System.Drawing.SystemColors.MenuText
        Me.lstLineUnit.FormattingEnabled = True
        Me.lstLineUnit.Location = New System.Drawing.Point(426, 41)
        Me.lstLineUnit.Name = "lstLineUnit"
        Me.lstLineUnit.Size = New System.Drawing.Size(81, 13)
        Me.lstLineUnit.TabIndex = 23
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(346, 60)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(64, 13)
        Me.Label19.TabIndex = 7
        Me.Label19.Text = "Class Field*:"
        '
        'lstLineHabQuan
        '
        Me.lstLineHabQuan.BackColor = System.Drawing.SystemColors.Info
        Me.lstLineHabQuan.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstLineHabQuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLineHabQuan.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lstLineHabQuan.FormattingEnabled = True
        Me.lstLineHabQuan.Location = New System.Drawing.Point(426, 22)
        Me.lstLineHabQuan.Name = "lstLineHabQuan"
        Me.lstLineHabQuan.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstLineHabQuan.Size = New System.Drawing.Size(113, 13)
        Me.lstLineHabQuan.TabIndex = 12
        '
        'cmdChngLineCls
        '
        Me.cmdChngLineCls.Location = New System.Drawing.Point(388, 79)
        Me.cmdChngLineCls.Name = "cmdChngLineCls"
        Me.cmdChngLineCls.Size = New System.Drawing.Size(61, 23)
        Me.cmdChngLineCls.TabIndex = 15
        Me.cmdChngLineCls.Text = "Change..."
        Me.cmdChngLineCls.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lstPolyLayers)
        Me.GroupBox2.Controls.Add(Me.lstPolyUnit)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.cmdChngPolyCls)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.lstPolyHabCls)
        Me.GroupBox2.Controls.Add(Me.lstPolyHabQuan)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Location = New System.Drawing.Point(20, 156)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(563, 123)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Polygon Layers"
        '
        'lstPolyLayers
        '
        Me.lstPolyLayers.FormattingEnabled = True
        Me.lstPolyLayers.Location = New System.Drawing.Point(10, 19)
        Me.lstPolyLayers.Name = "lstPolyLayers"
        Me.lstPolyLayers.Size = New System.Drawing.Size(306, 79)
        Me.lstPolyLayers.TabIndex = 18
        '
        'lstPolyUnit
        '
        Me.lstPolyUnit.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lstPolyUnit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstPolyUnit.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lstPolyUnit.FormattingEnabled = True
        Me.lstPolyUnit.Location = New System.Drawing.Point(426, 42)
        Me.lstPolyUnit.Name = "lstPolyUnit"
        Me.lstPolyUnit.Size = New System.Drawing.Size(81, 13)
        Me.lstPolyUnit.TabIndex = 22
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(352, 64)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(64, 13)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "Class Field*:"
        '
        'cmdChngPolyCls
        '
        Me.cmdChngPolyCls.Location = New System.Drawing.Point(388, 83)
        Me.cmdChngPolyCls.Name = "cmdChngPolyCls"
        Me.cmdChngPolyCls.Size = New System.Drawing.Size(61, 23)
        Me.cmdChngPolyCls.TabIndex = 16
        Me.cmdChngPolyCls.Text = "Change..."
        Me.cmdChngPolyCls.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label2.Location = New System.Drawing.Point(338, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Quantity Units*:"
        '
        'lstPolyHabCls
        '
        Me.lstPolyHabCls.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lstPolyHabCls.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstPolyHabCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstPolyHabCls.ForeColor = System.Drawing.Color.Black
        Me.lstPolyHabCls.FormattingEnabled = True
        Me.lstPolyHabCls.Location = New System.Drawing.Point(426, 64)
        Me.lstPolyHabCls.Name = "lstPolyHabCls"
        Me.lstPolyHabCls.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstPolyHabCls.Size = New System.Drawing.Size(113, 13)
        Me.lstPolyHabCls.TabIndex = 13
        '
        'lstPolyHabQuan
        '
        Me.lstPolyHabQuan.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lstPolyHabQuan.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstPolyHabQuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstPolyHabQuan.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lstPolyHabQuan.FormattingEnabled = True
        Me.lstPolyHabQuan.Location = New System.Drawing.Point(426, 19)
        Me.lstPolyHabQuan.Name = "lstPolyHabQuan"
        Me.lstPolyHabQuan.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstPolyHabQuan.Size = New System.Drawing.Size(113, 13)
        Me.lstPolyHabQuan.TabIndex = 14
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label20.Location = New System.Drawing.Point(338, 19)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(78, 13)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Quantity Field*:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label3.Location = New System.Drawing.Point(455, 282)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "(* = Required)"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.PictureBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox5)
        Me.TabPage2.Controls.Add(Me.Farme3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(620, 471)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Exclusions"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(139, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(223, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "FiPEx - Exclusions Options"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.FiPEX_AddIn_dotNet35_2.My.Resources.Resources.FiPEx_LOGOv3b_90x90
        Me.PictureBox3.Location = New System.Drawing.Point(22, 23)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(90, 90)
        Me.PictureBox3.TabIndex = 11
        Me.PictureBox3.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.cmdRemove2)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.lstVlsExcld)
        Me.GroupBox5.Controls.Add(Me.Label16)
        Me.GroupBox5.Controls.Add(Me.lstFtrsExcld)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.lstLyrsExcld)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 280)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(591, 149)
        Me.GroupBox5.TabIndex = 7
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "2. Current Exclusions"
        '
        'cmdRemove2
        '
        Me.cmdRemove2.Location = New System.Drawing.Point(218, 112)
        Me.cmdRemove2.Name = "cmdRemove2"
        Me.cmdRemove2.Size = New System.Drawing.Size(138, 23)
        Me.cmdRemove2.TabIndex = 6
        Me.cmdRemove2.Text = "Remove From Exclusions"
        Me.cmdRemove2.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(430, 25)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(37, 13)
        Me.Label17.TabIndex = 5
        Me.Label17.Text = "Value:"
        '
        'lstVlsExcld
        '
        Me.lstVlsExcld.BackColor = System.Drawing.SystemColors.MenuBar
        Me.lstVlsExcld.FormattingEnabled = True
        Me.lstVlsExcld.Location = New System.Drawing.Point(433, 41)
        Me.lstVlsExcld.Name = "lstVlsExcld"
        Me.lstVlsExcld.Size = New System.Drawing.Size(140, 56)
        Me.lstVlsExcld.TabIndex = 4
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(276, 25)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(32, 13)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Field:"
        '
        'lstFtrsExcld
        '
        Me.lstFtrsExcld.BackColor = System.Drawing.SystemColors.MenuBar
        Me.lstFtrsExcld.FormattingEnabled = True
        Me.lstFtrsExcld.Location = New System.Drawing.Point(279, 41)
        Me.lstFtrsExcld.Name = "lstFtrsExcld"
        Me.lstFtrsExcld.Size = New System.Drawing.Size(148, 56)
        Me.lstFtrsExcld.TabIndex = 2
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(15, 25)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(123, 13)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Layer (select to remove):"
        '
        'lstLyrsExcld
        '
        Me.lstLyrsExcld.FormattingEnabled = True
        Me.lstLyrsExcld.Location = New System.Drawing.Point(18, 41)
        Me.lstLyrsExcld.Name = "lstLyrsExcld"
        Me.lstLyrsExcld.Size = New System.Drawing.Size(244, 56)
        Me.lstLyrsExcld.TabIndex = 0
        '
        'Farme3
        '
        Me.Farme3.Controls.Add(Me.cmdAddExcld)
        Me.Farme3.Controls.Add(Me.Label14)
        Me.Farme3.Controls.Add(Me.Label13)
        Me.Farme3.Controls.Add(Me.lstFields)
        Me.Farme3.Controls.Add(Me.Label12)
        Me.Farme3.Controls.Add(Me.lstValues)
        Me.Farme3.Controls.Add(Me.lstLayers)
        Me.Farme3.Location = New System.Drawing.Point(6, 123)
        Me.Farme3.Name = "Farme3"
        Me.Farme3.Size = New System.Drawing.Size(591, 151)
        Me.Farme3.TabIndex = 1
        Me.Farme3.TabStop = False
        Me.Farme3.Text = "1. Select Exclusion "
        '
        'cmdAddExcld
        '
        Me.cmdAddExcld.Location = New System.Drawing.Point(236, 121)
        Me.cmdAddExcld.Name = "cmdAddExcld"
        Me.cmdAddExcld.Size = New System.Drawing.Size(102, 24)
        Me.cmdAddExcld.TabIndex = 6
        Me.cmdAddExcld.Text = "Add to Exclusions"
        Me.cmdAddExcld.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(430, 26)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(112, 13)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "Value (unique values):"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(276, 26)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(133, 13)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Field (populate 'Value' box)"
        '
        'lstFields
        '
        Me.lstFields.FormattingEnabled = True
        Me.lstFields.Location = New System.Drawing.Point(279, 42)
        Me.lstFields.Name = "lstFields"
        Me.lstFields.Size = New System.Drawing.Size(148, 69)
        Me.lstFields.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(15, 26)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(175, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Layer (select to populate 'Field' box:"
        '
        'lstValues
        '
        Me.lstValues.FormattingEnabled = True
        Me.lstValues.Location = New System.Drawing.Point(433, 42)
        Me.lstValues.Name = "lstValues"
        Me.lstValues.Size = New System.Drawing.Size(140, 69)
        Me.lstValues.TabIndex = 3
        '
        'lstLayers
        '
        Me.lstLayers.FormattingEnabled = True
        Me.lstLayers.Location = New System.Drawing.Point(18, 42)
        Me.lstLayers.Name = "lstLayers"
        Me.lstLayers.Size = New System.Drawing.Size(244, 69)
        Me.lstLayers.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.PictureBox2)
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(620, 471)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Barriers"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(139, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(201, 20)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "FiPEx - Barriers Options"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.FiPEX_AddIn_dotNet35_2.My.Resources.Resources.FiPEx_LOGOv3b_90x90
        Me.PictureBox2.Location = New System.Drawing.Point(22, 23)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(90, 90)
        Me.PictureBox2.TabIndex = 23
        Me.PictureBox2.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.GroupBox9)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.chkLstBarriersLayers)
        Me.GroupBox6.Location = New System.Drawing.Point(16, 132)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(556, 284)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.lstBarrierField)
        Me.GroupBox9.Controls.Add(Me.lstNaturalTFField)
        Me.GroupBox9.Controls.Add(Me.Label9)
        Me.GroupBox9.Controls.Add(Me.Label11)
        Me.GroupBox9.Controls.Add(Me.cmdSelectNaturalTF)
        Me.GroupBox9.Controls.Add(Me.lstPermField)
        Me.GroupBox9.Controls.Add(Me.cmdBarrierID)
        Me.GroupBox9.Controls.Add(Me.Label10)
        Me.GroupBox9.Controls.Add(Me.cmdSelectBarrierPerm)
        Me.GroupBox9.Location = New System.Drawing.Point(331, 18)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(200, 256)
        Me.GroupBox9.TabIndex = 22
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "2. Choose Barrier Layer Settings"
        '
        'lstBarrierField
        '
        Me.lstBarrierField.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.lstBarrierField.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstBarrierField.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBarrierField.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lstBarrierField.FormattingEnabled = True
        Me.lstBarrierField.Location = New System.Drawing.Point(39, 45)
        Me.lstBarrierField.Name = "lstBarrierField"
        Me.lstBarrierField.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstBarrierField.Size = New System.Drawing.Size(113, 13)
        Me.lstBarrierField.TabIndex = 13
        '
        'lstNaturalTFField
        '
        Me.lstNaturalTFField.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.lstNaturalTFField.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstNaturalTFField.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstNaturalTFField.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lstNaturalTFField.FormattingEnabled = True
        Me.lstNaturalTFField.Location = New System.Drawing.Point(38, 206)
        Me.lstNaturalTFField.Name = "lstNaturalTFField"
        Me.lstNaturalTFField.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstNaturalTFField.Size = New System.Drawing.Size(113, 13)
        Me.lstNaturalTFField.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(36, 29)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(116, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Barrier ID / Label Field:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(35, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 13)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Natural T/F Field:"
        '
        'cmdSelectNaturalTF
        '
        Me.cmdSelectNaturalTF.Location = New System.Drawing.Point(38, 225)
        Me.cmdSelectNaturalTF.Name = "cmdSelectNaturalTF"
        Me.cmdSelectNaturalTF.Size = New System.Drawing.Size(152, 23)
        Me.cmdSelectNaturalTF.TabIndex = 17
        Me.cmdSelectNaturalTF.Text = "Change Natural T/F Field..."
        Me.cmdSelectNaturalTF.UseVisualStyleBackColor = True
        '
        'lstPermField
        '
        Me.lstPermField.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.lstPermField.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lstPermField.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstPermField.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lstPermField.FormattingEnabled = True
        Me.lstPermField.Location = New System.Drawing.Point(39, 130)
        Me.lstPermField.Name = "lstPermField"
        Me.lstPermField.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstPermField.Size = New System.Drawing.Size(113, 13)
        Me.lstPermField.TabIndex = 20
        '
        'cmdBarrierID
        '
        Me.cmdBarrierID.Location = New System.Drawing.Point(39, 64)
        Me.cmdBarrierID.Name = "cmdBarrierID"
        Me.cmdBarrierID.Size = New System.Drawing.Size(112, 23)
        Me.cmdBarrierID.TabIndex = 15
        Me.cmdBarrierID.Text = "Change ID Field..."
        Me.cmdBarrierID.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(36, 114)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(95, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Permeability Field*:"
        '
        'cmdSelectBarrierPerm
        '
        Me.cmdSelectBarrierPerm.Location = New System.Drawing.Point(38, 149)
        Me.cmdSelectBarrierPerm.Name = "cmdSelectBarrierPerm"
        Me.cmdSelectBarrierPerm.Size = New System.Drawing.Size(149, 23)
        Me.cmdSelectBarrierPerm.TabIndex = 16
        Me.cmdSelectBarrierPerm.Text = "Change Permeability Field..."
        Me.cmdSelectBarrierPerm.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(13, 18)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(178, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "1. Select Barrier Layers For Analysis:"
        '
        'chkLstBarriersLayers
        '
        Me.chkLstBarriersLayers.FormattingEnabled = True
        Me.chkLstBarriersLayers.Location = New System.Drawing.Point(16, 37)
        Me.chkLstBarriersLayers.Name = "chkLstBarriersLayers"
        Me.chkLstBarriersLayers.Size = New System.Drawing.Size(273, 229)
        Me.chkLstBarriersLayers.TabIndex = 2
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label22)
        Me.TabPage4.Controls.Add(Me.PictureBox1)
        Me.TabPage4.Controls.Add(Me.frmDirection)
        Me.TabPage4.Controls.Add(Me.GroupBox4)
        Me.TabPage4.Controls.Add(Me.GroupBox1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(620, 471)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Advanced"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(139, 23)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(201, 20)
        Me.Label22.TabIndex = 25
        Me.Label22.Text = "FiPEx - Barriers Options"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.FiPEX_AddIn_dotNet35_2.My.Resources.Resources.FiPEx_LOGOv3b_90x90
        Me.PictureBox1.Location = New System.Drawing.Point(22, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 90)
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'frmDirection
        '
        Me.frmDirection.Controls.Add(Me.OptDown)
        Me.frmDirection.Controls.Add(Me.OptUp)
        Me.frmDirection.Location = New System.Drawing.Point(283, 125)
        Me.frmDirection.Name = "frmDirection"
        Me.frmDirection.Size = New System.Drawing.Size(129, 67)
        Me.frmDirection.TabIndex = 9
        Me.frmDirection.TabStop = False
        Me.frmDirection.Text = "Analysis Direction"
        '
        'OptDown
        '
        Me.OptDown.AutoSize = True
        Me.OptDown.Location = New System.Drawing.Point(22, 43)
        Me.OptDown.Name = "OptDown"
        Me.OptDown.Size = New System.Drawing.Size(84, 17)
        Me.OptDown.TabIndex = 1
        Me.OptDown.TabStop = True
        Me.OptDown.Text = "Downstream"
        Me.OptDown.UseVisualStyleBackColor = True
        '
        'OptUp
        '
        Me.OptUp.AutoSize = True
        Me.OptUp.Location = New System.Drawing.Point(22, 20)
        Me.OptUp.Name = "OptUp"
        Me.OptUp.Size = New System.Drawing.Size(70, 17)
        Me.OptUp.TabIndex = 0
        Me.OptUp.TabStop = True
        Me.OptUp.Text = "Upstream"
        Me.OptUp.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.GroupBox7)
        Me.GroupBox4.Controls.Add(Me.chkNaturalTF)
        Me.GroupBox4.Controls.Add(Me.chkBarrierPerm)
        Me.GroupBox4.Controls.Add(Me.chkConnect)
        Me.GroupBox4.Controls.Add(Me.cmdAddGDB)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.ChkDBFOutput)
        Me.GroupBox4.Controls.Add(Me.txtTablesPrefix)
        Me.GroupBox4.Controls.Add(Me.txtGDB)
        Me.GroupBox4.Location = New System.Drawing.Point(22, 198)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(533, 247)
        Me.GroupBox4.TabIndex = 8
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Table Output (requires at least one barriers layer to be selected in 'Barriers' t" & _
            "ab)"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.chkDCISectional)
        Me.GroupBox7.Controls.Add(Me.cmdDCIModelDir)
        Me.GroupBox7.Controls.Add(Me.txtDCIModelDir)
        Me.GroupBox7.Controls.Add(Me.txtRInstallDir)
        Me.GroupBox7.Controls.Add(Me.cmdRInstallDir)
        Me.GroupBox7.Controls.Add(Me.chkDCI)
        Me.GroupBox7.Location = New System.Drawing.Point(18, 128)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(509, 102)
        Me.GroupBox7.TabIndex = 9
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "DCI Calculation"
        '
        'chkDCISectional
        '
        Me.chkDCISectional.AutoSize = True
        Me.chkDCISectional.Location = New System.Drawing.Point(200, 19)
        Me.chkDCISectional.Name = "chkDCISectional"
        Me.chkDCISectional.Size = New System.Drawing.Size(144, 17)
        Me.chkDCISectional.TabIndex = 5
        Me.chkDCISectional.Text = "Calculate Segmental DCI"
        Me.chkDCISectional.UseVisualStyleBackColor = True
        '
        'cmdDCIModelDir
        '
        Me.cmdDCIModelDir.Location = New System.Drawing.Point(44, 75)
        Me.cmdDCIModelDir.Name = "cmdDCIModelDir"
        Me.cmdDCIModelDir.Size = New System.Drawing.Size(126, 20)
        Me.cmdDCIModelDir.TabIndex = 4
        Me.cmdDCIModelDir.Text = "DCI Model Dir:"
        Me.cmdDCIModelDir.UseVisualStyleBackColor = True
        '
        'txtDCIModelDir
        '
        Me.txtDCIModelDir.Location = New System.Drawing.Point(177, 76)
        Me.txtDCIModelDir.Name = "txtDCIModelDir"
        Me.txtDCIModelDir.Size = New System.Drawing.Size(325, 20)
        Me.txtDCIModelDir.TabIndex = 3
        '
        'txtRInstallDir
        '
        Me.txtRInstallDir.Location = New System.Drawing.Point(177, 45)
        Me.txtRInstallDir.Name = "txtRInstallDir"
        Me.txtRInstallDir.Size = New System.Drawing.Size(326, 20)
        Me.txtRInstallDir.TabIndex = 2
        '
        'cmdRInstallDir
        '
        Me.cmdRInstallDir.Location = New System.Drawing.Point(42, 43)
        Me.cmdRInstallDir.Name = "cmdRInstallDir"
        Me.cmdRInstallDir.Size = New System.Drawing.Size(129, 23)
        Me.cmdRInstallDir.TabIndex = 1
        Me.cmdRInstallDir.Text = "R Installation Directory:"
        Me.cmdRInstallDir.UseVisualStyleBackColor = True
        '
        'chkDCI
        '
        Me.chkDCI.AutoSize = True
        Me.chkDCI.Location = New System.Drawing.Point(16, 19)
        Me.chkDCI.Name = "chkDCI"
        Me.chkDCI.Size = New System.Drawing.Size(145, 17)
        Me.chkDCI.TabIndex = 0
        Me.chkDCI.Text = "Calculate DCId and DCIp"
        Me.chkDCI.UseVisualStyleBackColor = True
        '
        'chkNaturalTF
        '
        Me.chkNaturalTF.AutoSize = True
        Me.chkNaturalTF.Location = New System.Drawing.Point(308, 73)
        Me.chkNaturalTF.Name = "chkNaturalTF"
        Me.chkNaturalTF.Size = New System.Drawing.Size(141, 17)
        Me.chkNaturalTF.TabIndex = 8
        Me.chkNaturalTF.Text = "Include Natural T/F field"
        Me.chkNaturalTF.UseVisualStyleBackColor = True
        '
        'chkBarrierPerm
        '
        Me.chkBarrierPerm.AutoSize = True
        Me.chkBarrierPerm.Location = New System.Drawing.Point(308, 50)
        Me.chkBarrierPerm.Name = "chkBarrierPerm"
        Me.chkBarrierPerm.Size = New System.Drawing.Size(178, 17)
        Me.chkBarrierPerm.TabIndex = 7
        Me.chkBarrierPerm.Text = "Include Barrier Permeability Field"
        Me.chkBarrierPerm.UseVisualStyleBackColor = True
        '
        'chkConnect
        '
        Me.chkConnect.AutoSize = True
        Me.chkConnect.Location = New System.Drawing.Point(308, 96)
        Me.chkConnect.Name = "chkConnect"
        Me.chkConnect.Size = New System.Drawing.Size(147, 17)
        Me.chkConnect.TabIndex = 6
        Me.chkConnect.Text = "Include connectivity table"
        Me.chkConnect.UseVisualStyleBackColor = True
        '
        'cmdAddGDB
        '
        Me.cmdAddGDB.Location = New System.Drawing.Point(18, 50)
        Me.cmdAddGDB.Name = "cmdAddGDB"
        Me.cmdAddGDB.Size = New System.Drawing.Size(94, 23)
        Me.cmdAddGDB.TabIndex = 2
        Me.cmdAddGDB.Text = "Browse for GDB:"
        Me.cmdAddGDB.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(41, 92)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Tables Prefix: "
        '
        'ChkDBFOutput
        '
        Me.ChkDBFOutput.AutoSize = True
        Me.ChkDBFOutput.Location = New System.Drawing.Point(18, 19)
        Me.ChkDBFOutput.Name = "ChkDBFOutput"
        Me.ChkDBFOutput.Size = New System.Drawing.Size(198, 17)
        Me.ChkDBFOutput.TabIndex = 0
        Me.ChkDBFOutput.Text = "Output to GeoDatabase DBF Tables"
        Me.ChkDBFOutput.UseVisualStyleBackColor = True
        '
        'txtTablesPrefix
        '
        Me.txtTablesPrefix.Location = New System.Drawing.Point(118, 89)
        Me.txtTablesPrefix.Name = "txtTablesPrefix"
        Me.txtTablesPrefix.Size = New System.Drawing.Size(153, 20)
        Me.txtTablesPrefix.TabIndex = 3
        '
        'txtGDB
        '
        Me.txtGDB.Location = New System.Drawing.Point(118, 52)
        Me.txtGDB.Name = "txtGDB"
        Me.txtGDB.ReadOnly = True
        Me.txtGDB.Size = New System.Drawing.Size(153, 20)
        Me.txtGDB.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TxtOrder)
        Me.GroupBox1.Controls.Add(Me.ChkMaxOrd)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 125)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(230, 67)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = """Order"" of Analysis"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(112, 31)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Order:"
        '
        'TxtOrder
        '
        Me.TxtOrder.Location = New System.Drawing.Point(157, 28)
        Me.TxtOrder.Name = "TxtOrder"
        Me.TxtOrder.Size = New System.Drawing.Size(59, 20)
        Me.TxtOrder.TabIndex = 1
        '
        'ChkMaxOrd
        '
        Me.ChkMaxOrd.AutoSize = True
        Me.ChkMaxOrd.Location = New System.Drawing.Point(20, 30)
        Me.ChkMaxOrd.Name = "ChkMaxOrd"
        Me.ChkMaxOrd.Size = New System.Drawing.Size(70, 17)
        Me.ChkMaxOrd.TabIndex = 0
        Me.ChkMaxOrd.Text = "Maximum"
        Me.ChkMaxOrd.UseVisualStyleBackColor = True
        '
        'frmRunAdvancedAnalysis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(675, 587)
        Me.Controls.Add(Me.TabBarriers)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdRun)
        Me.Name = "frmRunAdvancedAnalysis"
        Me.Text = "FiPEx - Advanced Analysis"
        Me.TabBarriers.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.frmLayersInclude.ResumeLayout(False)
        Me.frmLayersInclude.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.Farme3.ResumeLayout(False)
        Me.Farme3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.frmDirection.ResumeLayout(False)
        Me.frmDirection.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdRun As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents TabBarriers As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents chkTotalPathDownHab As System.Windows.Forms.CheckBox
    Friend WithEvents chkTotalDownHab As System.Windows.Forms.CheckBox
    Friend WithEvents chkTotalUpHab As System.Windows.Forms.CheckBox
    Friend WithEvents chkPathDownHab As System.Windows.Forms.CheckBox
    Friend WithEvents chkDownHab As System.Windows.Forms.CheckBox
    Friend WithEvents chkUpHab As System.Windows.Forms.CheckBox
    Friend WithEvents frmLayersInclude As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents lstLineLayers As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lstLineHabCls As System.Windows.Forms.ListBox
    Friend WithEvents lstLineUnit As System.Windows.Forms.ListBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lstLineHabQuan As System.Windows.Forms.ListBox
    Friend WithEvents cmdChngLineCls As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lstPolyLayers As System.Windows.Forms.CheckedListBox
    Friend WithEvents lstPolyUnit As System.Windows.Forms.ListBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents cmdChngPolyCls As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lstPolyHabCls As System.Windows.Forms.ListBox
    Friend WithEvents lstPolyHabQuan As System.Windows.Forms.ListBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdRemove2 As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lstVlsExcld As System.Windows.Forms.ListBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lstFtrsExcld As System.Windows.Forms.ListBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lstLyrsExcld As System.Windows.Forms.ListBox
    Friend WithEvents Farme3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdAddExcld As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lstFields As System.Windows.Forms.ListBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lstValues As System.Windows.Forms.ListBox
    Friend WithEvents lstLayers As System.Windows.Forms.ListBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents lstBarrierField As System.Windows.Forms.ListBox
    Friend WithEvents lstNaturalTFField As System.Windows.Forms.ListBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmdSelectNaturalTF As System.Windows.Forms.Button
    Friend WithEvents lstPermField As System.Windows.Forms.ListBox
    Friend WithEvents cmdBarrierID As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmdSelectBarrierPerm As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chkLstBarriersLayers As System.Windows.Forms.CheckedListBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents frmDirection As System.Windows.Forms.GroupBox
    Friend WithEvents OptDown As System.Windows.Forms.RadioButton
    Friend WithEvents OptUp As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents chkDCISectional As System.Windows.Forms.CheckBox
    Friend WithEvents cmdDCIModelDir As System.Windows.Forms.Button
    Friend WithEvents txtDCIModelDir As System.Windows.Forms.TextBox
    Friend WithEvents txtRInstallDir As System.Windows.Forms.TextBox
    Friend WithEvents cmdRInstallDir As System.Windows.Forms.Button
    Friend WithEvents chkDCI As System.Windows.Forms.CheckBox
    Friend WithEvents chkNaturalTF As System.Windows.Forms.CheckBox
    Friend WithEvents chkBarrierPerm As System.Windows.Forms.CheckBox
    Friend WithEvents chkConnect As System.Windows.Forms.CheckBox
    Friend WithEvents cmdAddGDB As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ChkDBFOutput As System.Windows.Forms.CheckBox
    Friend WithEvents txtTablesPrefix As System.Windows.Forms.TextBox
    Friend WithEvents txtGDB As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtOrder As System.Windows.Forms.TextBox
    Friend WithEvents ChkMaxOrd As System.Windows.Forms.CheckBox
End Class
