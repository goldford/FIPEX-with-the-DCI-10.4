Public Class MultiItem1
    Inherits ESRI.ArcGIS.Desktop.AddIns.MultiItem

  Public Sub New()

  End Sub

  Protected Overrides Sub OnPopup(ByVal items As ItemCollection)

  End Sub

  Protected Overrides Sub OnClick(ByVal item As Item)

  End Sub
End Class